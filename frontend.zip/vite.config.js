// vite.config.js
export default { server: { port: 5173 } };
